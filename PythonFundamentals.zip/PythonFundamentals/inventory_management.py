inventory = [
    ('Soaps', 10),
    ('Paste', 0),
    ('Powder', 15),
    ('Facewash', 0)
]

def check_inventory(inventory):
    for item, quantity in inventory:
        if quantity == 0:
            print(f"{item} is out of stock !!")
        else:
            print(f"{item} is in stock with {quantity} units.")
            
            
check_inventory(inventory)