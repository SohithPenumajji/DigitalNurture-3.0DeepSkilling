num_of_hours = 40
hourly_rate = 15

def calculate_pay(hours, rate):
    return hours * rate

total = calculate_pay(num_of_hours, hourly_rate)
print(total)
