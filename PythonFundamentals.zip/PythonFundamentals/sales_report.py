sales = [200, 600, 150, 800, 300]

def generate_report(sales):
    for sale in sales:
        if sale > 500:
            print(f"{sale} over 500 !!")
        else:
            print(f"Sale: {sale}")
            
    print()

generate_report(sales)

total_sales = sum(sales)
    
print(f"Total Sales for the Month: {total_sales}")