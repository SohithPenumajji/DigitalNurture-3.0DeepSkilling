order_amount = int(input("Enter the order amount: \n"))

def apply_discount(amount):
    if(amount > 100):
        return amount * 0.9
    else:
        return amount

final_price = apply_discount(order_amount)
print(f"The Total price is: ${final_price}")