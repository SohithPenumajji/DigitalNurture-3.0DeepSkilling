package FeedbackAnalysis;

@FunctionalInterface
public interface FeedbackProcessor {
    void process(Feedback feedback);
}
