import React from "react";
import "../App.css";


function Header() {
    return (
        <header>
            <h1 className="header">Charity Catalyst</h1>
        </header>
    );
}

export default Header;